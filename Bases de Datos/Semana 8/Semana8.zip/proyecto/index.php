<!DOCTYPE html>
<html>
<head>
    <title>Departamentos</title>
    <link rel="stylesheet" type="text/css" href="css/estilos.css">
</head>
<body>
    <h1>Lista de Departamentos</h1>

    <div class="formulario-container">
        <form action="MostrarUsuarios.php" method="get">
            <input type="submit" value="Mostrar usuarios">
        </form>
    </div>
    <br>
    <div>
        <form action="MostrarProyectos.php" method="get">
            <input type="submit" value="Mostrar proyectos">
        </form>
    </div>
    <br>
    <div>
        <form method="get" action="AgregarDepartamento.php">
            <input type="submit" value="Agregar departamento nuevo">
        </form>
    </div>

    <?php
    // Incluir la clase Libro y la clase LibroDAOMySQL
    require_once 'controller/DepartamentoController.php';
    require_once 'model/Departamento.php';

    // Crear una instancia de LibroDAOMySQL (proporciona los detalles de conexión)
    $departamentoDAO = new DepartamentoController("localhost", "root", "", "edbm");
    $departamentos=$departamentoDAO->getAllDepartamento();

    echo '<br>';
    // Mostrar la lista de libros en una tabla
    if (!empty($departamentos)) {
        echo '<table border="1">';
        echo '<tr><th>Nombre</th><th>Descripcion</th><th>Presupuesto</th></tr>';
        foreach ($departamentos as $departamento) {
            echo '<tr>';
            echo '<td>' . $departamento->getNombre() . '</td>';
            echo '<td>' . $departamento->getDescripcion() . '</td>';
            echo '<td>' . $departamento->getPresupuesto() . '</td>';
            echo '</tr>';
        }
        echo '</table>';
    } else {
        echo '<p>No se encontraron departamentos en la base de datos.</p>';
    }
    ?>


</body>
</html>