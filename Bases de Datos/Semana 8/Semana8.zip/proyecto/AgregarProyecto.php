<!DOCTYPE html>
<html>
<head>
    <title>Agregar Proyecto</title>
    <link rel="stylesheet" type="text/css" href="css/estilos.css">
</head>
<body>
    <h1>Agregar proyecto</h1>
    
    <form method="post" class="formulario">
        <label for="descripcion">Descripcion:</label>
        <textarea name="descripcion" id="descripcion" rows="4" cols="50" required></textarea>
        <br>

        <label for="fec_inic">Fecha de inicio:</label>
        <input type="date" name="fec_inic" id="fec_inic" required min="<?php echo date('Y-m-d'); ?>">
        <br>

        <label for="fec_fin">Fecha de fin:</label>
        <input type="date" name="fec_fin" id="fec_fin" required min="<?php echo date('Y-m-d'); ?>">
        <br>

        <label for="presupuesto">Presupuesto:</label>
        <input type="number" name="presupuesto" id="presupuesto" min="0" oninput="validity.valid||(value='');" required>
        <br>

        <label for="departamento">Departamentos:</label>
            <select name="departamento" id="departamento" required>
                <option value="Legal">Legal</option>
                <option value="Engineering">Engineering</option>
                <option value="Training">Training</option>
                <option value="Marketing">Marketing</option>
                <option value="Services">Services</option>
            </select>
        <br>

        <input type="submit" value="Agregar">
    </form>

    <?php
    // Incluir la clase Libro y la clase LibroDAOMySQL
    require_once 'controller/ProyectoController.php';
    require_once 'model/Proyecto.php';

    // Crear una instancia de LibroDAOMySQL (proporciona los detalles de conexión)
    $proyectoDAO = new ProyectoController("localhost", "root", "", "edbm");

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Obtener los valores del formulario
        $descripcion = $_POST["descripcion"];
        $fec_inicio = $_POST["fec_inic"];
        $fec_fin = $_POST["fec_fin"];
        $presupuesto = $_POST["presupuesto"];
        $departamento = $_POST["departamento"];

      // Crear una instancia de la clase Libro con los valores del formulario
        $proyecto = new Proyecto($descripcion,$fec_inicio,$fec_fin,$presupuesto,$departamento);

      // Guardar el libro en la base de datos utilizando la instancia de LibroDAOMySQL
        $proyectoDAO->createProyecto($proyecto);
    }
    ?>

    <br>
    <form action="index.php" method="get">
        <input type="submit" value="Regresar al catalogo de departamentos">
    </form>
</body>
</html>

