<!DOCTYPE html>
<html>
<head>
    <title>Proyectos</title>
    <link rel="stylesheet" type="text/css" href="css/estilos.css">
</head>
<body>
    <h1>Lista de proyectos</h1>

    <div class="formulario-container">
        <form action="index.php" method="get">
            <input type="submit" value="Mostrar departamentos">
        </form>
    </div>
    <br>
    <div>
        <form action="MostrarUsuarios.php" method="get">
            <input type="submit" value="Mostrar usuarios">
        </form>
    </div>
    <br>
    <div>
        <form method="get" action="AgregarProyecto.php">
            <input type="submit" value="Agregar proyecto nuevo">
        </form>
    </div>

    <?php
    // Incluir la clase Libro y la clase LibroDAOMySQL
    require_once 'controller/ProyectoController.php';
    require_once 'model/Proyecto.php';

    // Crear una instancia de LibroDAOMySQL (proporciona los detalles de conexión)
    $proyectoDAO = new ProyectoController("localhost", "root", "", "edbm");
    $proyectos=$proyectoDAO->getAllProyecto();

    echo '<br>';
    // Mostrar la lista de libros en una tabla
    if (!empty($proyectos)) {
        echo '<table border="1">';
        echo '<tr><th>Descripcion</th><th>Fecha inicio</th><th>Fecha fin</th><th>Presupuesto</th><th>Departamento</th></tr>';
        foreach ($proyectos as $proyecto) {
            echo '<tr>';
            echo '<td>' . $proyecto->getDescripcion() . '</td>';
            echo '<td>' . $proyecto->getFechaInicio() . '</td>';
            echo '<td>' . $proyecto->getFechaFin() . '</td>';
            echo '<td>' . $proyecto->getPresupuesto() . '</td>';
            echo '<td>' . $proyecto->getDepartamento() . '</td>';
            echo '</tr>';
        }
        echo '</table>';
    } else {
        echo '<p>No se encontraron proyectos en la base de datos.</p>';
    }
    ?>
</body>
</html>