<!DOCTYPE html>
<html>
<head>
    <title>Agregar departamento</title>
    <link rel="stylesheet" type="text/css" href="css/estilos.css">
</head>
<body>
    <h1>Agregar departamento</h1>
    
    <form method="post" class="formulario">
        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" id="nombre" required>
        <br>

        <label for="descripcion">Descripcion:</label>
        <input type="text" name="descripcion" id="descripcion" required>
        <br>

        <label for="presupuesto">Presupuesto:</label>
        <input type="number" name="presupuesto" id="presupuesto" min="0" oninput="validity.valid||(value='');" required>
        <br>

        <input type="submit" value="Agregar">
    </form>

    <?php
    // Incluir la clase Libro y la clase LibroDAOMySQL
    require_once 'controller/DepartamentoController.php';
    require_once 'model/Departamento.php';

    // Crear una instancia de LibroDAOMySQL (proporciona los detalles de conexión)
    $departamentoDAO = new DepartamentoController("localhost", "root", "", "edbm");

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Obtener los valores del formulario
        $nombre = $_POST["nombre"];
        $descripcion = $_POST["descripcion"];
        $presupuesto = $_POST["presupuesto"];

      // Crear una instancia de la clase Libro con los valores del formulario
        $departamento = new Departamento($nombre, $descripcion, $presupuesto);

      // Guardar el libro en la base de datos utilizando la instancia de LibroDAOMySQL
        $departamentoDAO->createDepartamento($departamento);
    }
    ?>

    <br>
    <form action="index.php" method="get">
        <input type="submit" value="Regresar al catalogo de departamentos">
    </form>
</body>
</html>

