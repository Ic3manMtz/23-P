<?php
require_once('dao\EmpleadoDAO.php');
require_once('model\Empleado.php');

class EmpleadoController implements EmpleadoDAO{
    private $conexion;

    public function __construct($host, $usuario, $contrasena, $base){
        $this->conexion=new mysqli($host, $usuario, $contrasena, $base);
        if($this->conexion->connect_error){
            die("Error de conexión: " . $this->conexion->connect_error);
        }
    }

    public function getAllEmpleado(){
        $empleados=array();
        return $empleados;
    }

    public function createEmpleado(Empleado $empleado){
    }

    public function deleteEmpleado(Empleado $empleado){
    }

    public function updateEmpleado(Empleado $empleado){
    }
}
?>