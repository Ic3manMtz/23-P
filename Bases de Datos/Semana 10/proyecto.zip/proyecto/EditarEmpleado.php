<!DOCTYPE html>
<html>
<head>
    <title>Editar empleado</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
</head>
<body>
    <div class="d-flex flex-column align-items-center justify-content-center" style="height: 100vh;">
        <div class="alert alert-danger" role="alert">
            Empleado a editar
        </div>

        <?php
            if (isset($_GET['array'])) {
                $encodedArray = $_GET['array'];
                $array = unserialize(urldecode($encodedArray));

                require_once 'model/Empleado.php';
                require_once 'controller/EmpleadoController.php';

                $conexion = new mysqli('localhost','root','','edbm');
                $empleadoDAO = new EmpleadoController($conexion);

                $array = [$array];
                $empleados = $empleadoDAO->getEmpleadosById($array);

                echo '<br>';
                echo '<div class="container">';
                echo '<div class="col-md-6 mx-auto">';
                // Mostrar la lista de libros en una tabla
                if (!empty($empleados)) {
                    echo '<table class="table table-condensed table-striped">';
                    echo '<tr style="background:#337ab7; color:white;">
                    <th class="text-center" width="10%">Id Empleado</th>
                    <th class="text-center" width="10%">Nombre</th>
                    <th class="text-center" width="15%">Apellido Paterno</th>
                    <th class="text-center" width="15%">Apellido Materno</th></tr>';
                    foreach ($empleados as $empleado) {
                        echo '<tr>';
                        echo '<td class="text-center">' . $empleado->getId() . '</td>';
                        echo '<td class="text-center" contenteditable="true">' . $empleado->getNombre() . '</td>';
                        echo '<td class="text-center">' . $empleado->getApPaterno() . '</td>';
                        echo '<td class="text-center">' . $empleado->getApMaterno() . '</td>';
                        echo '</tr>';
                    }
                    echo '</table>';
                } else {
                    echo '<p>No se encontraron los empleados en la base de datos.</p>';
                }
                echo '</div>';
                echo '</div>';

                if(isset($_POST['confirmar'])){
                    $result=$empleadoDAO->deleteEmpleado($array);
                    if($result==1){
                        echo '<script>alert("Los empleados han sido eliminados. Serás redirigido a la página principal.");</script>';
                    }else{
                        echo '<script>alert("Ocurrió un error al eliminar, intenta de nuevo. Serás redirigido a la página principal.");</script>';
                    }
                    echo '<script>window.location.href = "index.php";</script>';
                    exit();
                }
                
            }
        ?>

        <div class="d-flex justify-content-center">
            <form method="post" class="mx-2">
                <input type="submit" class="btn btn-primary" value="Confirmar" name="confirmar">
            </form>
            <form action="index.php" method="get" class="mx-2">
                <input type="submit" class="btn btn-secondary" value="Cancelar">
            </form>
        </div>
    </div>
</body>
</html>
