#!/bin/bash

echo -e "\nIniciando compilación del programa"
javac Peer.java

if [ $? -eq 0 ]; then
    echo -e "\n\tCompilación exitosa!\n"
else
    echo -e "\n\tError en compilación, intente de nuevo\n"
    exit 1
fi

echo "Ingresa el número de procesos..."
read processes

for ((i=0; i<$processes; i++))do
    fuser -k 600$i/tcp &>/dev/null
    echo "Ejecutando el programa para el proceso [$i]"
    java Peer $i $processes &
done

